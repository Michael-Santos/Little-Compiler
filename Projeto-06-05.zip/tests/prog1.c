#include <stdio.h>
// Programa "prog1"

