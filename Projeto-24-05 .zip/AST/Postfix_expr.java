package AST;

public interface Postfix_expr {
  public void genC(PW pw);
}
