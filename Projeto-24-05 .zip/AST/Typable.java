package AST;

public interface Typable {
    public Identifier getId();
    public String getType();
}
