package AST;

public interface Stmt {
	public void genC(PW pw);
}
