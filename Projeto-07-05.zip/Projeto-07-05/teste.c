#include <stdio.h>
// Programa "teste"

char[] oi = "OI";
char[] oi = "OI";

int main () {
   char[] hello = "CHUPA MINHA ROLA";
   
   printf(hello);
}
